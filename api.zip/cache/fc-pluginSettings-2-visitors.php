<?php return array (
  'blockContent' => 
  array (
    'en_US' => '<p><span class="title">Visitors Statistic</span></p>
<p><a href="https://info.flagcounter.com/lcqK"><img src="https://s11.flagcounter.com/count2/lcqK/bg_FFFFFF/txt_000000/border_CCCCCC/columns_2/maxflags_14/viewers_0/labels_1/pageviews_1/flags_0/percent_0/" alt="Flag Counter" border="0"></a></p>
<p><a title="Web Analytics Made Easy - StatCounter" href="https://statcounter.com/" target="_blank" rel="noopener"><img src="https://c.statcounter.com/12036808/0/c99f892f/0/" alt="Web Analytics Made Easy - StatCounter"></a> <a href="https://statcounter.com/p12036808/?guest=1">View My Stats</a></p>',
  ),
  'context' => 1,
  'enabled' => true,
  'seq' => 3,
); ?>