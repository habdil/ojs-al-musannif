<?php return array (
  'plugins.generic.pdfJsViewer.name' => 'PDF.JS PDF Viewer',
  'plugins.generic.pdfJsViewer.description' => 'This plugin uses the <a href="http://mozilla.github.io/pdf.js">pdf.js PDF viewer</a> to embed PDFs on the article and issue galley view pages.',
); ?>