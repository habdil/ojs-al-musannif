<?php return array (
  65 => 
  array (
    0 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '47',
      'representation_id' => '47',
      2 => '14',
      'metric' => '14',
    ),
    1 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '47',
      'representation_id' => '47',
      2 => '24',
      'metric' => '24',
    ),
    2 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '47',
      'representation_id' => '47',
      2 => '19',
      'metric' => '19',
    ),
    3 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '47',
      'representation_id' => '47',
      2 => '7',
      'metric' => '7',
    ),
    4 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    5 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '47',
      'representation_id' => '47',
      2 => '5',
      'metric' => '5',
    ),
    6 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    7 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    8 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    9 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '47',
      'representation_id' => '47',
      2 => '9',
      'metric' => '9',
    ),
    10 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '47',
      'representation_id' => '47',
      2 => '8',
      'metric' => '8',
    ),
    11 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '47',
      'representation_id' => '47',
      2 => '8',
      'metric' => '8',
    ),
    12 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '47',
      'representation_id' => '47',
      2 => '7',
      'metric' => '7',
    ),
    13 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '47',
      'representation_id' => '47',
      2 => '7',
      'metric' => '7',
    ),
    14 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    15 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '47',
      'representation_id' => '47',
      2 => '5',
      'metric' => '5',
    ),
    16 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '47',
      'representation_id' => '47',
      2 => '6',
      'metric' => '6',
    ),
    17 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '47',
      'representation_id' => '47',
      2 => '13',
      'metric' => '13',
    ),
    18 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '47',
      'representation_id' => '47',
      2 => '9',
      'metric' => '9',
    ),
    19 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '47',
      'representation_id' => '47',
      2 => '15',
      'metric' => '15',
    ),
    20 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    21 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '47',
      'representation_id' => '47',
      2 => '4',
      'metric' => '4',
    ),
    22 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '47',
      'representation_id' => '47',
      2 => '8',
      'metric' => '8',
    ),
    23 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    24 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '47',
      'representation_id' => '47',
      2 => '5',
      'metric' => '5',
    ),
    25 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    26 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '47',
      'representation_id' => '47',
      2 => '4',
      'metric' => '4',
    ),
    27 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '47',
      'representation_id' => '47',
      2 => '3',
      'metric' => '3',
    ),
    28 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '47',
      'representation_id' => '47',
      2 => '12',
      'metric' => '12',
    ),
    29 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '47',
      'representation_id' => '47',
      2 => '5',
      'metric' => '5',
    ),
    30 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '47',
      'representation_id' => '47',
      2 => '10',
      'metric' => '10',
    ),
    31 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '47',
      'representation_id' => '47',
      2 => '12',
      'metric' => '12',
    ),
    32 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '47',
      'representation_id' => '47',
      2 => '9',
      'metric' => '9',
    ),
    33 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '47',
      'representation_id' => '47',
      2 => '20',
      'metric' => '20',
    ),
    34 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '47',
      'representation_id' => '47',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>