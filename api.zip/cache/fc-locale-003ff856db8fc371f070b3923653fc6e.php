<?php return array (
  'plugins.reports.reviews.displayName' => ' Laporan Review ',
  'plugins.reports.reviews.description' => ' Plugin ini mengimplementasikan laporan CSV yang berisi daftar tugas review untuk sebuah jurnal.',
  'plugins.reports.reviews.round' => ' Putaran ',
  'plugins.reports.reviews.reviewerId' => ' ID Reviewer ',
  'plugins.reports.reviews.reviewer' => ' Reviewer ',
  'plugins.reports.reviews.dateAssigned' => ' Tanggal Ditugaskan ',
  'plugins.reports.reviews.dateNotified' => ' Tanggal Diberitahu ',
  'plugins.reports.reviews.dateConfirmed' => ' Tanggal Dikonfirmasi ',
  'plugins.reports.reviews.dateCompleted' => ' Tanggal Diselesaikan ',
  'plugins.reports.reviews.dateReminded' => ' Tanggal Diperingatkan ',
); ?>