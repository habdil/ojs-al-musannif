<?php return array (
  85 => 
  array (
    0 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '56',
      'representation_id' => '56',
      2 => '26',
      'metric' => '26',
    ),
    1 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '56',
      'representation_id' => '56',
      2 => '51',
      'metric' => '51',
    ),
    2 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '56',
      'representation_id' => '56',
      2 => '59',
      'metric' => '59',
    ),
    3 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '56',
      'representation_id' => '56',
      2 => '21',
      'metric' => '21',
    ),
    4 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '56',
      'representation_id' => '56',
      2 => '35',
      'metric' => '35',
    ),
    5 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '56',
      'representation_id' => '56',
      2 => '50',
      'metric' => '50',
    ),
    6 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '56',
      'representation_id' => '56',
      2 => '79',
      'metric' => '79',
    ),
    7 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '56',
      'representation_id' => '56',
      2 => '54',
      'metric' => '54',
    ),
    8 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '56',
      'representation_id' => '56',
      2 => '50',
      'metric' => '50',
    ),
    9 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '56',
      'representation_id' => '56',
      2 => '23',
      'metric' => '23',
    ),
    10 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '56',
      'representation_id' => '56',
      2 => '45',
      'metric' => '45',
    ),
    11 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '56',
      'representation_id' => '56',
      2 => '48',
      'metric' => '48',
    ),
    12 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '56',
      'representation_id' => '56',
      2 => '64',
      'metric' => '64',
    ),
    13 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '56',
      'representation_id' => '56',
      2 => '56',
      'metric' => '56',
    ),
    14 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '56',
      'representation_id' => '56',
      2 => '46',
      'metric' => '46',
    ),
    15 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '56',
      'representation_id' => '56',
      2 => '40',
      'metric' => '40',
    ),
    16 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '56',
      'representation_id' => '56',
      2 => '45',
      'metric' => '45',
    ),
    17 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '56',
      'representation_id' => '56',
      2 => '52',
      'metric' => '52',
    ),
    18 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '56',
      'representation_id' => '56',
      2 => '67',
      'metric' => '67',
    ),
    19 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '56',
      'representation_id' => '56',
      2 => '109',
      'metric' => '109',
    ),
    20 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '56',
      'representation_id' => '56',
      2 => '62',
      'metric' => '62',
    ),
    21 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '56',
      'representation_id' => '56',
      2 => '46',
      'metric' => '46',
    ),
    22 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '56',
      'representation_id' => '56',
      2 => '22',
      'metric' => '22',
    ),
    23 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '56',
      'representation_id' => '56',
      2 => '24',
      'metric' => '24',
    ),
    24 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '56',
      'representation_id' => '56',
      2 => '39',
      'metric' => '39',
    ),
    25 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '56',
      'representation_id' => '56',
      2 => '24',
      'metric' => '24',
    ),
    26 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '56',
      'representation_id' => '56',
      2 => '23',
      'metric' => '23',
    ),
    27 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '56',
      'representation_id' => '56',
      2 => '20',
      'metric' => '20',
    ),
    28 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '56',
      'representation_id' => '56',
      2 => '6',
      'metric' => '6',
    ),
  ),
); ?>