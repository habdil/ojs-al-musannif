<?php return array (
  'plugins.generic.googleScholar.name' => 'Google Scholar Indexing Plugin',
  'plugins.generic.googleScholar.description' => 'This plugin enables indexing of published content in Google Scholar.',
); ?>