<?php return array (
  89 => 
  array (
    0 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '78',
      'representation_id' => '78',
      2 => '11',
      'metric' => '11',
    ),
    1 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '78',
      'representation_id' => '78',
      2 => '13',
      'metric' => '13',
    ),
    2 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '78',
      'representation_id' => '78',
      2 => '4',
      'metric' => '4',
    ),
    3 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '78',
      'representation_id' => '78',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>