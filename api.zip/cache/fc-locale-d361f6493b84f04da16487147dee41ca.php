<?php return array (
  'plugins.block.languageToggle.displayName' => 'Language Toggle Block',
  'plugins.block.languageToggle.description' => 'This plugin provides the sidebar language toggler.',
); ?>