<?php return array (
  45 => 
  array (
    0 => 
    array (
      0 => '202106',
      'month' => '202106',
      1 => '31',
      'representation_id' => '31',
      2 => '2',
      'metric' => '2',
    ),
    1 => 
    array (
      0 => '202107',
      'month' => '202107',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    2 => 
    array (
      0 => '202108',
      'month' => '202108',
      1 => '31',
      'representation_id' => '31',
      2 => '9',
      'metric' => '9',
    ),
    3 => 
    array (
      0 => '202109',
      'month' => '202109',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    4 => 
    array (
      0 => '202110',
      'month' => '202110',
      1 => '31',
      'representation_id' => '31',
      2 => '38',
      'metric' => '38',
    ),
    5 => 
    array (
      0 => '202111',
      'month' => '202111',
      1 => '31',
      'representation_id' => '31',
      2 => '36',
      'metric' => '36',
    ),
    6 => 
    array (
      0 => '202112',
      'month' => '202112',
      1 => '31',
      'representation_id' => '31',
      2 => '44',
      'metric' => '44',
    ),
    7 => 
    array (
      0 => '202201',
      'month' => '202201',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    8 => 
    array (
      0 => '202202',
      'month' => '202202',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    9 => 
    array (
      0 => '202203',
      'month' => '202203',
      1 => '31',
      'representation_id' => '31',
      2 => '6',
      'metric' => '6',
    ),
    10 => 
    array (
      0 => '202204',
      'month' => '202204',
      1 => '31',
      'representation_id' => '31',
      2 => '17',
      'metric' => '17',
    ),
    11 => 
    array (
      0 => '202205',
      'month' => '202205',
      1 => '31',
      'representation_id' => '31',
      2 => '5',
      'metric' => '5',
    ),
    12 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    13 => 
    array (
      0 => '202207',
      'month' => '202207',
      1 => '31',
      'representation_id' => '31',
      2 => '4',
      'metric' => '4',
    ),
    14 => 
    array (
      0 => '202208',
      'month' => '202208',
      1 => '31',
      'representation_id' => '31',
      2 => '5',
      'metric' => '5',
    ),
    15 => 
    array (
      0 => '202209',
      'month' => '202209',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    16 => 
    array (
      0 => '202210',
      'month' => '202210',
      1 => '31',
      'representation_id' => '31',
      2 => '6',
      'metric' => '6',
    ),
    17 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    18 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '31',
      'representation_id' => '31',
      2 => '6',
      'metric' => '6',
    ),
    19 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '31',
      'representation_id' => '31',
      2 => '4',
      'metric' => '4',
    ),
    20 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '31',
      'representation_id' => '31',
      2 => '6',
      'metric' => '6',
    ),
    21 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '31',
      'representation_id' => '31',
      2 => '4',
      'metric' => '4',
    ),
    22 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '31',
      'representation_id' => '31',
      2 => '7',
      'metric' => '7',
    ),
    23 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '31',
      'representation_id' => '31',
      2 => '11',
      'metric' => '11',
    ),
    24 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '31',
      'representation_id' => '31',
      2 => '11',
      'metric' => '11',
    ),
    25 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    26 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    27 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '31',
      'representation_id' => '31',
      2 => '7',
      'metric' => '7',
    ),
    28 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '31',
      'representation_id' => '31',
      2 => '27',
      'metric' => '27',
    ),
    29 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '31',
      'representation_id' => '31',
      2 => '7',
      'metric' => '7',
    ),
    30 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '31',
      'representation_id' => '31',
      2 => '13',
      'metric' => '13',
    ),
    31 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '31',
      'representation_id' => '31',
      2 => '7',
      'metric' => '7',
    ),
    32 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    33 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '31',
      'representation_id' => '31',
      2 => '5',
      'metric' => '5',
    ),
    34 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '31',
      'representation_id' => '31',
      2 => '17',
      'metric' => '17',
    ),
    35 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '31',
      'representation_id' => '31',
      2 => '9',
      'metric' => '9',
    ),
    36 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '31',
      'representation_id' => '31',
      2 => '15',
      'metric' => '15',
    ),
    37 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '31',
      'representation_id' => '31',
      2 => '9',
      'metric' => '9',
    ),
    38 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '31',
      'representation_id' => '31',
      2 => '7',
      'metric' => '7',
    ),
    39 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    40 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    41 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '31',
      'representation_id' => '31',
      2 => '10',
      'metric' => '10',
    ),
    42 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '31',
      'representation_id' => '31',
      2 => '16',
      'metric' => '16',
    ),
    43 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '31',
      'representation_id' => '31',
      2 => '2',
      'metric' => '2',
    ),
    44 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '31',
      'representation_id' => '31',
      2 => '3',
      'metric' => '3',
    ),
    45 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '31',
      'representation_id' => '31',
      2 => '6',
      'metric' => '6',
    ),
    46 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '31',
      'representation_id' => '31',
      2 => '9',
      'metric' => '9',
    ),
    47 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '31',
      'representation_id' => '31',
      2 => '9',
      'metric' => '9',
    ),
    48 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '31',
      'representation_id' => '31',
      2 => '4',
      'metric' => '4',
    ),
    49 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '31',
      'representation_id' => '31',
      2 => '12',
      'metric' => '12',
    ),
    50 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '31',
      'representation_id' => '31',
      2 => '5',
      'metric' => '5',
    ),
  ),
); ?>