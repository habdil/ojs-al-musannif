<?php return array (
  'apiKey' => '',
  'automaticRegistration' => false,
  'testMode' => false,
); ?>