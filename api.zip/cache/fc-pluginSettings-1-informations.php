<?php return array (
  'blockContent' => 
  array (
    'en_US' => '<div class="pkp_block block_Information"><span class="title">Main Menu</span>
<div class="content">
<ul>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/focus_scope"> Focus and Scope</a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/about/editorialTeam"> Editorial Team </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/Reviewers"> Reviewers </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/Indexing"> Indexing </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/about/submissions#AuthorGuidelines"> Author Guidelines </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/APCs"> Article Processing Charges </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/license_copyrights"> Licensing and Copyright </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/peer-review-process"> Peer Review Process </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/plagiarisms"> Plagiarism Screening </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/publication-ethics"> Publication Ethics </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/open_access_policy"> Open Access Policy </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/information/readers"> For Readers </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/information/authors"> For Authors </a></li>
<li><a href="https://jurnal.mtsddicilellang.sch.id/index.php/al-musannif/information/librarians"> For Librarians </a></li>
<li><a href="https://pkp.sfu.ca/ojs/"> Open Journal Systems</a></li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="/public/site/images/editor/review-format.png"></p>
</div>
</div>',
  ),
  'context' => 1,
  'enabled' => false,
  'seq' => 3,
); ?>