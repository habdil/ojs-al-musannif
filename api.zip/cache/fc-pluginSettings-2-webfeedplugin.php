<?php return array (
  'displayItems' => true,
  'displayPage' => 'homepage',
  'enabled' => true,
); ?>