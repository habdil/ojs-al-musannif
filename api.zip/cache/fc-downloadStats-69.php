<?php return array (
  69 => 
  array (
    0 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '53',
      'representation_id' => '53',
      2 => '15',
      'metric' => '15',
    ),
    1 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '53',
      'representation_id' => '53',
      2 => '25',
      'metric' => '25',
    ),
    2 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '53',
      'representation_id' => '53',
      2 => '28',
      'metric' => '28',
    ),
    3 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '53',
      'representation_id' => '53',
      2 => '14',
      'metric' => '14',
    ),
    4 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '53',
      'representation_id' => '53',
      2 => '20',
      'metric' => '20',
    ),
    5 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '53',
      'representation_id' => '53',
      2 => '21',
      'metric' => '21',
    ),
    6 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '53',
      'representation_id' => '53',
      2 => '21',
      'metric' => '21',
    ),
    7 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '53',
      'representation_id' => '53',
      2 => '17',
      'metric' => '17',
    ),
    8 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '53',
      'representation_id' => '53',
      2 => '137',
      'metric' => '137',
    ),
    9 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '53',
      'representation_id' => '53',
      2 => '128',
      'metric' => '128',
    ),
    10 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '53',
      'representation_id' => '53',
      2 => '151',
      'metric' => '151',
    ),
    11 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '53',
      'representation_id' => '53',
      2 => '75',
      'metric' => '75',
    ),
    12 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '53',
      'representation_id' => '53',
      2 => '50',
      'metric' => '50',
    ),
    13 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '53',
      'representation_id' => '53',
      2 => '48',
      'metric' => '48',
    ),
    14 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '53',
      'representation_id' => '53',
      2 => '141',
      'metric' => '141',
    ),
    15 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '53',
      'representation_id' => '53',
      2 => '75',
      'metric' => '75',
    ),
    16 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '53',
      'representation_id' => '53',
      2 => '81',
      'metric' => '81',
    ),
    17 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '53',
      'representation_id' => '53',
      2 => '96',
      'metric' => '96',
    ),
    18 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '53',
      'representation_id' => '53',
      2 => '63',
      'metric' => '63',
    ),
    19 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '53',
      'representation_id' => '53',
      2 => '45',
      'metric' => '45',
    ),
    20 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '53',
      'representation_id' => '53',
      2 => '177',
      'metric' => '177',
    ),
    21 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '53',
      'representation_id' => '53',
      2 => '230',
      'metric' => '230',
    ),
    22 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '53',
      'representation_id' => '53',
      2 => '149',
      'metric' => '149',
    ),
    23 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '53',
      'representation_id' => '53',
      2 => '100',
      'metric' => '100',
    ),
    24 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '53',
      'representation_id' => '53',
      2 => '41',
      'metric' => '41',
    ),
    25 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '53',
      'representation_id' => '53',
      2 => '33',
      'metric' => '33',
    ),
    26 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '53',
      'representation_id' => '53',
      2 => '132',
      'metric' => '132',
    ),
    27 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '53',
      'representation_id' => '53',
      2 => '114',
      'metric' => '114',
    ),
    28 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '53',
      'representation_id' => '53',
      2 => '94',
      'metric' => '94',
    ),
    29 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '53',
      'representation_id' => '53',
      2 => '59',
      'metric' => '59',
    ),
    30 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '53',
      'representation_id' => '53',
      2 => '22',
      'metric' => '22',
    ),
    31 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '53',
      'representation_id' => '53',
      2 => '34',
      'metric' => '34',
    ),
  ),
); ?>