<?php return array (
  'plugins.block.makeSubmission.displayName' => '"Make a Submission" Block',
  'plugins.block.makeSubmission.description' => 'This plugin provides a sidebar block with a "Make a Submission" link.',
  'plugins.block.makeSubmission.linkLabel' => 'Make a Submission',
); ?>