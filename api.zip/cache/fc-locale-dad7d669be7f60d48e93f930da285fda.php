<?php return array (
  'plugins.generic.htmlArticleGalley.displayName' => 'HTML Article Galley',
  'plugins.generic.htmlArticleGalley.description' => 'This plugin provides rendering support for HTML Article Galleys.',
); ?>