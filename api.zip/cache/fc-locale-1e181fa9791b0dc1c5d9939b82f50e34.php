<?php return array (
  'plugins.block.browse' => 'Browse',
  'plugins.block.browse.displayName' => 'Browse Block',
  'plugins.block.browse.description' => 'This plugin provides sidebar "browse" tools.',
  'plugins.block.browse.category' => 'Categories',
); ?>