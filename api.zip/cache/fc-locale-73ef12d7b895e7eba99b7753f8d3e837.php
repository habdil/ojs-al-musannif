<?php return array (
  'api.submissions.403.unpublishedIssues' => 'You do not have permission to view unpublished issues.',
); ?>