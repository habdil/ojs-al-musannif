<?php return array (
  'plugins.generic.recommendByAuthor.displayName' => 'Recommend Articles by Author',
  'plugins.generic.recommendByAuthor.description' => 'This plugin inserts a list of articles by the same author on the article abstract page.',
  'plugins.generic.recommendByAuthor.heading' => 'Most read articles by the same author(s)',
  'plugins.generic.recommendByAuthor.noMetric' => 'Obs.: This plugin requires at least one statistics/report plugin to be enabled. If your statistics plugins provide more than one metric then please also select a main metric on the admin\'s site settings page and/or on the journal manager\'s settings pages.',
); ?>