<?php return array (
  'doiIssueSuffixPattern' => NULL,
  'doiPrefix' => '10.56324',
  'doiRepresentationSuffixPattern' => NULL,
  'doiSubmissionSuffixPattern' => NULL,
  'doiSuffix' => 'default',
  'enabled' => true,
  'enableIssueDoi' => true,
  'enableRepresentationDoi' => false,
  'enableSubmissionDoi' => true,
); ?>