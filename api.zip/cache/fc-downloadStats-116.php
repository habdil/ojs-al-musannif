<?php return array (
  116 => 
  array (
    0 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '77',
      'representation_id' => '77',
      2 => '46',
      'metric' => '46',
    ),
    1 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '77',
      'representation_id' => '77',
      2 => '37',
      'metric' => '37',
    ),
    2 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '77',
      'representation_id' => '77',
      2 => '25',
      'metric' => '25',
    ),
    3 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '77',
      'representation_id' => '77',
      2 => '17',
      'metric' => '17',
    ),
  ),
); ?>