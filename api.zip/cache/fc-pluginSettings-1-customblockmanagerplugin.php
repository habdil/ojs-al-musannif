<?php return array (
  'blocks' => 
  array (
    0 => 'QuickMenu',
    2 => 'Informations',
    4 => 'Visitors',
    5 => 'Tools',
    7 => 'CurrentIssue',
    9 => 'MAP',
    10 => 'scopus_citedness',
    12 => 'Contact',
    13 => 'sinta',
    14 => 'Colaboration',
  ),
  'enabled' => true,
); ?>