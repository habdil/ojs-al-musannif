<?php return array (
  43 => 
  array (
    0 => 
    array (
      0 => '202106',
      'month' => '202106',
      1 => '30',
      'representation_id' => '30',
      2 => '3',
      'metric' => '3',
    ),
    1 => 
    array (
      0 => '202107',
      'month' => '202107',
      1 => '30',
      'representation_id' => '30',
      2 => '4',
      'metric' => '4',
    ),
    2 => 
    array (
      0 => '202108',
      'month' => '202108',
      1 => '30',
      'representation_id' => '30',
      2 => '3',
      'metric' => '3',
    ),
    3 => 
    array (
      0 => '202109',
      'month' => '202109',
      1 => '30',
      'representation_id' => '30',
      2 => '8',
      'metric' => '8',
    ),
    4 => 
    array (
      0 => '202110',
      'month' => '202110',
      1 => '30',
      'representation_id' => '30',
      2 => '16',
      'metric' => '16',
    ),
    5 => 
    array (
      0 => '202111',
      'month' => '202111',
      1 => '30',
      'representation_id' => '30',
      2 => '30',
      'metric' => '30',
    ),
    6 => 
    array (
      0 => '202112',
      'month' => '202112',
      1 => '30',
      'representation_id' => '30',
      2 => '39',
      'metric' => '39',
    ),
    7 => 
    array (
      0 => '202201',
      'month' => '202201',
      1 => '30',
      'representation_id' => '30',
      2 => '41',
      'metric' => '41',
    ),
    8 => 
    array (
      0 => '202202',
      'month' => '202202',
      1 => '30',
      'representation_id' => '30',
      2 => '22',
      'metric' => '22',
    ),
    9 => 
    array (
      0 => '202203',
      'month' => '202203',
      1 => '30',
      'representation_id' => '30',
      2 => '9',
      'metric' => '9',
    ),
    10 => 
    array (
      0 => '202204',
      'month' => '202204',
      1 => '30',
      'representation_id' => '30',
      2 => '18',
      'metric' => '18',
    ),
    11 => 
    array (
      0 => '202205',
      'month' => '202205',
      1 => '30',
      'representation_id' => '30',
      2 => '9',
      'metric' => '9',
    ),
    12 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '30',
      'representation_id' => '30',
      2 => '18',
      'metric' => '18',
    ),
    13 => 
    array (
      0 => '202207',
      'month' => '202207',
      1 => '30',
      'representation_id' => '30',
      2 => '15',
      'metric' => '15',
    ),
    14 => 
    array (
      0 => '202208',
      'month' => '202208',
      1 => '30',
      'representation_id' => '30',
      2 => '10',
      'metric' => '10',
    ),
    15 => 
    array (
      0 => '202209',
      'month' => '202209',
      1 => '30',
      'representation_id' => '30',
      2 => '7',
      'metric' => '7',
    ),
    16 => 
    array (
      0 => '202210',
      'month' => '202210',
      1 => '30',
      'representation_id' => '30',
      2 => '15',
      'metric' => '15',
    ),
    17 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '30',
      'representation_id' => '30',
      2 => '9',
      'metric' => '9',
    ),
    18 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '30',
      'representation_id' => '30',
      2 => '20',
      'metric' => '20',
    ),
    19 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '30',
      'representation_id' => '30',
      2 => '13',
      'metric' => '13',
    ),
    20 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '30',
      'representation_id' => '30',
      2 => '22',
      'metric' => '22',
    ),
    21 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '30',
      'representation_id' => '30',
      2 => '14',
      'metric' => '14',
    ),
    22 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '30',
      'representation_id' => '30',
      2 => '6',
      'metric' => '6',
    ),
    23 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '30',
      'representation_id' => '30',
      2 => '27',
      'metric' => '27',
    ),
    24 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '30',
      'representation_id' => '30',
      2 => '25',
      'metric' => '25',
    ),
    25 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '30',
      'representation_id' => '30',
      2 => '16',
      'metric' => '16',
    ),
    26 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '30',
      'representation_id' => '30',
      2 => '7',
      'metric' => '7',
    ),
    27 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '30',
      'representation_id' => '30',
      2 => '5',
      'metric' => '5',
    ),
    28 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '30',
      'representation_id' => '30',
      2 => '18',
      'metric' => '18',
    ),
    29 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '30',
      'representation_id' => '30',
      2 => '20',
      'metric' => '20',
    ),
    30 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '30',
      'representation_id' => '30',
      2 => '11',
      'metric' => '11',
    ),
    31 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '30',
      'representation_id' => '30',
      2 => '15',
      'metric' => '15',
    ),
    32 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '30',
      'representation_id' => '30',
      2 => '8',
      'metric' => '8',
    ),
    33 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '30',
      'representation_id' => '30',
      2 => '12',
      'metric' => '12',
    ),
    34 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '30',
      'representation_id' => '30',
      2 => '12',
      'metric' => '12',
    ),
    35 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '30',
      'representation_id' => '30',
      2 => '25',
      'metric' => '25',
    ),
    36 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '30',
      'representation_id' => '30',
      2 => '18',
      'metric' => '18',
    ),
    37 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '30',
      'representation_id' => '30',
      2 => '11',
      'metric' => '11',
    ),
    38 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '30',
      'representation_id' => '30',
      2 => '10',
      'metric' => '10',
    ),
    39 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '30',
      'representation_id' => '30',
      2 => '16',
      'metric' => '16',
    ),
    40 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '30',
      'representation_id' => '30',
      2 => '28',
      'metric' => '28',
    ),
    41 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '30',
      'representation_id' => '30',
      2 => '22',
      'metric' => '22',
    ),
    42 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '30',
      'representation_id' => '30',
      2 => '28',
      'metric' => '28',
    ),
    43 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '30',
      'representation_id' => '30',
      2 => '15',
      'metric' => '15',
    ),
    44 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '30',
      'representation_id' => '30',
      2 => '10',
      'metric' => '10',
    ),
    45 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '30',
      'representation_id' => '30',
      2 => '11',
      'metric' => '11',
    ),
    46 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '30',
      'representation_id' => '30',
      2 => '13',
      'metric' => '13',
    ),
    47 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '30',
      'representation_id' => '30',
      2 => '34',
      'metric' => '34',
    ),
    48 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '30',
      'representation_id' => '30',
      2 => '8',
      'metric' => '8',
    ),
    49 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '30',
      'representation_id' => '30',
      2 => '10',
      'metric' => '10',
    ),
    50 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '30',
      'representation_id' => '30',
      2 => '18',
      'metric' => '18',
    ),
    51 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '30',
      'representation_id' => '30',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>