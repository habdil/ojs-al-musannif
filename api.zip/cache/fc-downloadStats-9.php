<?php return array (
  9 => 
  array (
    0 => 
    array (
      0 => '201905',
      'month' => '201905',
      1 => '2',
      'representation_id' => '2',
      2 => '3',
      'metric' => '3',
    ),
    1 => 
    array (
      0 => '201906',
      'month' => '201906',
      1 => '2',
      'representation_id' => '2',
      2 => '7',
      'metric' => '7',
    ),
    2 => 
    array (
      0 => '201907',
      'month' => '201907',
      1 => '2',
      'representation_id' => '2',
      2 => '5',
      'metric' => '5',
    ),
    3 => 
    array (
      0 => '201908',
      'month' => '201908',
      1 => '2',
      'representation_id' => '2',
      2 => '3',
      'metric' => '3',
    ),
    4 => 
    array (
      0 => '201909',
      'month' => '201909',
      1 => '2',
      'representation_id' => '2',
      2 => '2',
      'metric' => '2',
    ),
    5 => 
    array (
      0 => '201910',
      'month' => '201910',
      1 => '2',
      'representation_id' => '2',
      2 => '66',
      'metric' => '66',
    ),
    6 => 
    array (
      0 => '201911',
      'month' => '201911',
      1 => '2',
      'representation_id' => '2',
      2 => '105',
      'metric' => '105',
    ),
    7 => 
    array (
      0 => '201912',
      'month' => '201912',
      1 => '2',
      'representation_id' => '2',
      2 => '92',
      'metric' => '92',
    ),
    8 => 
    array (
      0 => '202001',
      'month' => '202001',
      1 => '2',
      'representation_id' => '2',
      2 => '85',
      'metric' => '85',
    ),
    9 => 
    array (
      0 => '202002',
      'month' => '202002',
      1 => '2',
      'representation_id' => '2',
      2 => '29',
      'metric' => '29',
    ),
    10 => 
    array (
      0 => '202003',
      'month' => '202003',
      1 => '2',
      'representation_id' => '2',
      2 => '76',
      'metric' => '76',
    ),
    11 => 
    array (
      0 => '202004',
      'month' => '202004',
      1 => '2',
      'representation_id' => '2',
      2 => '35',
      'metric' => '35',
    ),
    12 => 
    array (
      0 => '202005',
      'month' => '202005',
      1 => '2',
      'representation_id' => '2',
      2 => '37',
      'metric' => '37',
    ),
    13 => 
    array (
      0 => '202006',
      'month' => '202006',
      1 => '2',
      'representation_id' => '2',
      2 => '18',
      'metric' => '18',
    ),
    14 => 
    array (
      0 => '202007',
      'month' => '202007',
      1 => '2',
      'representation_id' => '2',
      2 => '21',
      'metric' => '21',
    ),
    15 => 
    array (
      0 => '202008',
      'month' => '202008',
      1 => '2',
      'representation_id' => '2',
      2 => '13',
      'metric' => '13',
    ),
    16 => 
    array (
      0 => '202009',
      'month' => '202009',
      1 => '2',
      'representation_id' => '2',
      2 => '65',
      'metric' => '65',
    ),
    17 => 
    array (
      0 => '202010',
      'month' => '202010',
      1 => '2',
      'representation_id' => '2',
      2 => '50',
      'metric' => '50',
    ),
    18 => 
    array (
      0 => '202011',
      'month' => '202011',
      1 => '2',
      'representation_id' => '2',
      2 => '68',
      'metric' => '68',
    ),
    19 => 
    array (
      0 => '202012',
      'month' => '202012',
      1 => '2',
      'representation_id' => '2',
      2 => '100',
      'metric' => '100',
    ),
    20 => 
    array (
      0 => '202101',
      'month' => '202101',
      1 => '2',
      'representation_id' => '2',
      2 => '44',
      'metric' => '44',
    ),
    21 => 
    array (
      0 => '202102',
      'month' => '202102',
      1 => '2',
      'representation_id' => '2',
      2 => '26',
      'metric' => '26',
    ),
    22 => 
    array (
      0 => '202103',
      'month' => '202103',
      1 => '2',
      'representation_id' => '2',
      2 => '55',
      'metric' => '55',
    ),
    23 => 
    array (
      0 => '202104',
      'month' => '202104',
      1 => '2',
      'representation_id' => '2',
      2 => '53',
      'metric' => '53',
    ),
    24 => 
    array (
      0 => '202105',
      'month' => '202105',
      1 => '2',
      'representation_id' => '2',
      2 => '35',
      'metric' => '35',
    ),
    25 => 
    array (
      0 => '202106',
      'month' => '202106',
      1 => '2',
      'representation_id' => '2',
      2 => '27',
      'metric' => '27',
    ),
    26 => 
    array (
      0 => '202107',
      'month' => '202107',
      1 => '2',
      'representation_id' => '2',
      2 => '39',
      'metric' => '39',
    ),
    27 => 
    array (
      0 => '202108',
      'month' => '202108',
      1 => '2',
      'representation_id' => '2',
      2 => '34',
      'metric' => '34',
    ),
    28 => 
    array (
      0 => '202109',
      'month' => '202109',
      1 => '2',
      'representation_id' => '2',
      2 => '116',
      'metric' => '116',
    ),
    29 => 
    array (
      0 => '202110',
      'month' => '202110',
      1 => '2',
      'representation_id' => '2',
      2 => '132',
      'metric' => '132',
    ),
    30 => 
    array (
      0 => '202111',
      'month' => '202111',
      1 => '2',
      'representation_id' => '2',
      2 => '26',
      'metric' => '26',
    ),
    31 => 
    array (
      0 => '202111',
      'month' => '202111',
      1 => '35',
      'representation_id' => '35',
      2 => '64',
      'metric' => '64',
    ),
    32 => 
    array (
      0 => '202112',
      'month' => '202112',
      1 => '35',
      'representation_id' => '35',
      2 => '65',
      'metric' => '65',
    ),
    33 => 
    array (
      0 => '202201',
      'month' => '202201',
      1 => '35',
      'representation_id' => '35',
      2 => '29',
      'metric' => '29',
    ),
    34 => 
    array (
      0 => '202202',
      'month' => '202202',
      1 => '35',
      'representation_id' => '35',
      2 => '34',
      'metric' => '34',
    ),
    35 => 
    array (
      0 => '202203',
      'month' => '202203',
      1 => '35',
      'representation_id' => '35',
      2 => '46',
      'metric' => '46',
    ),
    36 => 
    array (
      0 => '202204',
      'month' => '202204',
      1 => '35',
      'representation_id' => '35',
      2 => '50',
      'metric' => '50',
    ),
    37 => 
    array (
      0 => '202205',
      'month' => '202205',
      1 => '35',
      'representation_id' => '35',
      2 => '50',
      'metric' => '50',
    ),
    38 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '35',
      'representation_id' => '35',
      2 => '72',
      'metric' => '72',
    ),
    39 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '43',
      'representation_id' => '43',
      2 => '25',
      'metric' => '25',
    ),
    40 => 
    array (
      0 => '202207',
      'month' => '202207',
      1 => '43',
      'representation_id' => '43',
      2 => '54',
      'metric' => '54',
    ),
    41 => 
    array (
      0 => '202208',
      'month' => '202208',
      1 => '43',
      'representation_id' => '43',
      2 => '43',
      'metric' => '43',
    ),
    42 => 
    array (
      0 => '202209',
      'month' => '202209',
      1 => '43',
      'representation_id' => '43',
      2 => '93',
      'metric' => '93',
    ),
    43 => 
    array (
      0 => '202210',
      'month' => '202210',
      1 => '43',
      'representation_id' => '43',
      2 => '201',
      'metric' => '201',
    ),
    44 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '43',
      'representation_id' => '43',
      2 => '117',
      'metric' => '117',
    ),
    45 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '43',
      'representation_id' => '43',
      2 => '110',
      'metric' => '110',
    ),
    46 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '43',
      'representation_id' => '43',
      2 => '37',
      'metric' => '37',
    ),
    47 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '43',
      'representation_id' => '43',
      2 => '43',
      'metric' => '43',
    ),
    48 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '43',
      'representation_id' => '43',
      2 => '113',
      'metric' => '113',
    ),
    49 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '43',
      'representation_id' => '43',
      2 => '45',
      'metric' => '45',
    ),
    50 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '43',
      'representation_id' => '43',
      2 => '107',
      'metric' => '107',
    ),
    51 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '43',
      'representation_id' => '43',
      2 => '80',
      'metric' => '80',
    ),
    52 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '43',
      'representation_id' => '43',
      2 => '43',
      'metric' => '43',
    ),
    53 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '43',
      'representation_id' => '43',
      2 => '30',
      'metric' => '30',
    ),
    54 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '43',
      'representation_id' => '43',
      2 => '97',
      'metric' => '97',
    ),
    55 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '43',
      'representation_id' => '43',
      2 => '157',
      'metric' => '157',
    ),
    56 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '43',
      'representation_id' => '43',
      2 => '139',
      'metric' => '139',
    ),
    57 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '43',
      'representation_id' => '43',
      2 => '85',
      'metric' => '85',
    ),
    58 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '43',
      'representation_id' => '43',
      2 => '34',
      'metric' => '34',
    ),
    59 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '43',
      'representation_id' => '43',
      2 => '42',
      'metric' => '42',
    ),
    60 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '43',
      'representation_id' => '43',
      2 => '95',
      'metric' => '95',
    ),
    61 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '43',
      'representation_id' => '43',
      2 => '44',
      'metric' => '44',
    ),
    62 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '43',
      'representation_id' => '43',
      2 => '90',
      'metric' => '90',
    ),
    63 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '43',
      'representation_id' => '43',
      2 => '80',
      'metric' => '80',
    ),
    64 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '43',
      'representation_id' => '43',
      2 => '35',
      'metric' => '35',
    ),
    65 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '43',
      'representation_id' => '43',
      2 => '28',
      'metric' => '28',
    ),
    66 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '43',
      'representation_id' => '43',
      2 => '117',
      'metric' => '117',
    ),
    67 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '43',
      'representation_id' => '43',
      2 => '122',
      'metric' => '122',
    ),
    68 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '43',
      'representation_id' => '43',
      2 => '91',
      'metric' => '91',
    ),
    69 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '43',
      'representation_id' => '43',
      2 => '53',
      'metric' => '53',
    ),
    70 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '43',
      'representation_id' => '43',
      2 => '36',
      'metric' => '36',
    ),
    71 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '43',
      'representation_id' => '43',
      2 => '42',
      'metric' => '42',
    ),
    72 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '43',
      'representation_id' => '43',
      2 => '55',
      'metric' => '55',
    ),
    73 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '43',
      'representation_id' => '43',
      2 => '33',
      'metric' => '33',
    ),
    74 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '43',
      'representation_id' => '43',
      2 => '63',
      'metric' => '63',
    ),
    75 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '43',
      'representation_id' => '43',
      2 => '52',
      'metric' => '52',
    ),
    76 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '43',
      'representation_id' => '43',
      2 => '7',
      'metric' => '7',
    ),
    77 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '43',
      'representation_id' => '43',
      2 => '22',
      'metric' => '22',
    ),
    78 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '43',
      'representation_id' => '43',
      2 => '3',
      'metric' => '3',
    ),
  ),
); ?>