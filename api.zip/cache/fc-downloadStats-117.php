<?php return array (
  117 => 
  array (
    0 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '62',
      'representation_id' => '62',
      2 => '2',
      'metric' => '2',
    ),
    1 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '62',
      'representation_id' => '62',
      2 => '21',
      'metric' => '21',
    ),
    2 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '62',
      'representation_id' => '62',
      2 => '8',
      'metric' => '8',
    ),
    3 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '62',
      'representation_id' => '62',
      2 => '17',
      'metric' => '17',
    ),
    4 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '62',
      'representation_id' => '62',
      2 => '13',
      'metric' => '13',
    ),
    5 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '62',
      'representation_id' => '62',
      2 => '8',
      'metric' => '8',
    ),
    6 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '62',
      'representation_id' => '62',
      2 => '3',
      'metric' => '3',
    ),
  ),
); ?>