<?php return array (
  187 => 
  array (
    0 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '73',
      'representation_id' => '73',
      2 => '7',
      'metric' => '7',
    ),
    1 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '73',
      'representation_id' => '73',
      2 => '21',
      'metric' => '21',
    ),
    2 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '73',
      'representation_id' => '73',
      2 => '2',
      'metric' => '2',
    ),
  ),
); ?>