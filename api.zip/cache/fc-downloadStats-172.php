<?php return array (
  172 => 
  array (
    0 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '80',
      'representation_id' => '80',
      2 => '17',
      'metric' => '17',
    ),
    1 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '80',
      'representation_id' => '80',
      2 => '14',
      'metric' => '14',
    ),
    2 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '80',
      'representation_id' => '80',
      2 => '14',
      'metric' => '14',
    ),
    3 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '80',
      'representation_id' => '80',
      2 => '25',
      'metric' => '25',
    ),
  ),
); ?>