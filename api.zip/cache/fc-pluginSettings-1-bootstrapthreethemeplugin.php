<?php return array (
  'bootstrapTheme' => 'journal',
  'enabled' => true,
); ?>