<?php return array (
  63 => 
  array (
    0 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '55',
      'representation_id' => '55',
      2 => '3',
      'metric' => '3',
    ),
    1 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '55',
      'representation_id' => '55',
      2 => '17',
      'metric' => '17',
    ),
    2 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '55',
      'representation_id' => '55',
      2 => '19',
      'metric' => '19',
    ),
    3 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '55',
      'representation_id' => '55',
      2 => '13',
      'metric' => '13',
    ),
    4 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '55',
      'representation_id' => '55',
      2 => '29',
      'metric' => '29',
    ),
    5 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '55',
      'representation_id' => '55',
      2 => '18',
      'metric' => '18',
    ),
    6 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '55',
      'representation_id' => '55',
      2 => '14',
      'metric' => '14',
    ),
    7 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '55',
      'representation_id' => '55',
      2 => '17',
      'metric' => '17',
    ),
    8 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '55',
      'representation_id' => '55',
      2 => '20',
      'metric' => '20',
    ),
    9 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '55',
      'representation_id' => '55',
      2 => '18',
      'metric' => '18',
    ),
    10 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '55',
      'representation_id' => '55',
      2 => '17',
      'metric' => '17',
    ),
    11 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '55',
      'representation_id' => '55',
      2 => '8',
      'metric' => '8',
    ),
    12 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '55',
      'representation_id' => '55',
      2 => '13',
      'metric' => '13',
    ),
    13 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '55',
      'representation_id' => '55',
      2 => '9',
      'metric' => '9',
    ),
    14 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '55',
      'representation_id' => '55',
      2 => '10',
      'metric' => '10',
    ),
    15 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '55',
      'representation_id' => '55',
      2 => '9',
      'metric' => '9',
    ),
    16 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '55',
      'representation_id' => '55',
      2 => '22',
      'metric' => '22',
    ),
    17 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '55',
      'representation_id' => '55',
      2 => '9',
      'metric' => '9',
    ),
    18 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '55',
      'representation_id' => '55',
      2 => '11',
      'metric' => '11',
    ),
    19 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '55',
      'representation_id' => '55',
      2 => '9',
      'metric' => '9',
    ),
    20 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '55',
      'representation_id' => '55',
      2 => '4',
      'metric' => '4',
    ),
    21 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '55',
      'representation_id' => '55',
      2 => '8',
      'metric' => '8',
    ),
    22 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '55',
      'representation_id' => '55',
      2 => '11',
      'metric' => '11',
    ),
    23 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '55',
      'representation_id' => '55',
      2 => '2',
      'metric' => '2',
    ),
    24 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '55',
      'representation_id' => '55',
      2 => '10',
      'metric' => '10',
    ),
    25 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '55',
      'representation_id' => '55',
      2 => '6',
      'metric' => '6',
    ),
    26 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '55',
      'representation_id' => '55',
      2 => '8',
      'metric' => '8',
    ),
    27 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '55',
      'representation_id' => '55',
      2 => '12',
      'metric' => '12',
    ),
    28 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '55',
      'representation_id' => '55',
      2 => '6',
      'metric' => '6',
    ),
    29 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '55',
      'representation_id' => '55',
      2 => '26',
      'metric' => '26',
    ),
    30 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '55',
      'representation_id' => '55',
      2 => '18',
      'metric' => '18',
    ),
    31 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '55',
      'representation_id' => '55',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>