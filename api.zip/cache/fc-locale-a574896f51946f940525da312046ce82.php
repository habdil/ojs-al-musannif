<?php return array (
  'plugins.metadata.dc11.displayName' => 'Metadata Dublin Core 1.1',
  'plugins.metadata.dc11.description' => 'Berkontribusi terhadap skema dan adapter aplikasi Dublin Core versi 1.1.',
); ?>