<?php return array (
  'AFN' => 
  array (
    0 => 'Afghani',
    1 => '971',
  ),
  'DZD' => 
  array (
    0 => 'Algerian Dinar',
    1 => '012',
  ),
  'ARS' => 
  array (
    0 => 'Argentine Peso',
    1 => '032',
  ),
  'AMD' => 
  array (
    0 => 'Armenian Dram',
    1 => '051',
  ),
  'AWG' => 
  array (
    0 => 'Aruban Florin',
    1 => '533',
  ),
  'AUD' => 
  array (
    0 => 'Australian Dollar',
    1 => '036',
  ),
  'AZN' => 
  array (
    0 => 'Azerbaijanian Manat',
    1 => '944',
  ),
  'BSD' => 
  array (
    0 => 'Bahamian Dollar',
    1 => '044',
  ),
  'BHD' => 
  array (
    0 => 'Bahraini Dinar',
    1 => '048',
  ),
  'THB' => 
  array (
    0 => 'Baht',
    1 => '764',
  ),
  'PAB' => 
  array (
    0 => 'Balboa',
    1 => '590',
  ),
  'BBD' => 
  array (
    0 => 'Barbados Dollar',
    1 => '052',
  ),
  'BYN' => 
  array (
    0 => 'Belarusian Ruble',
    1 => '933',
  ),
  'BZD' => 
  array (
    0 => 'Belize Dollar',
    1 => '084',
  ),
  'BMD' => 
  array (
    0 => 'Bermudian Dollar',
    1 => '060',
  ),
  'BOB' => 
  array (
    0 => 'Boliviano',
    1 => '068',
  ),
  'VEF' => 
  array (
    0 => 'Bolívar',
    1 => '937',
  ),
  'BRL' => 
  array (
    0 => 'Brazilian Real',
    1 => '986',
  ),
  'BND' => 
  array (
    0 => 'Brunei Dollar',
    1 => '096',
  ),
  'BGN' => 
  array (
    0 => 'Bulgarian Lev',
    1 => '975',
  ),
  'BIF' => 
  array (
    0 => 'Burundi Franc',
    1 => '108',
  ),
  'XOF' => 
  array (
    0 => 'CFA Franc BCEAO',
    1 => '952',
  ),
  'XAF' => 
  array (
    0 => 'CFA Franc BEAC',
    1 => '950',
  ),
  'XPF' => 
  array (
    0 => 'CFP Franc',
    1 => '953',
  ),
  'CVE' => 
  array (
    0 => 'Cabo Verde Escudo',
    1 => '132',
  ),
  'CAD' => 
  array (
    0 => 'Canadian Dollar',
    1 => '124',
  ),
  'KYD' => 
  array (
    0 => 'Cayman Islands Dollar',
    1 => '136',
  ),
  'CLP' => 
  array (
    0 => 'Chilean Peso',
    1 => '152',
  ),
  'COP' => 
  array (
    0 => 'Colombian peso',
    1 => '170',
  ),
  'KMF' => 
  array (
    0 => 'Comoro Franc',
    1 => '174',
  ),
  'CDF' => 
  array (
    0 => 'Congolese Franc',
    1 => '976',
  ),
  'BAM' => 
  array (
    0 => 'Convertible Mark',
    1 => '977',
  ),
  'NIO' => 
  array (
    0 => 'Cordoba Oro',
    1 => '558',
  ),
  'CRC' => 
  array (
    0 => 'Costa Rican Colon',
    1 => '188',
  ),
  'CUP' => 
  array (
    0 => 'Cuban Peso',
    1 => '192',
  ),
  'CZK' => 
  array (
    0 => 'Czech Koruna',
    1 => '203',
  ),
  'GMD' => 
  array (
    0 => 'Dalasi',
    1 => '270',
  ),
  'DKK' => 
  array (
    0 => 'Danish Krone',
    1 => '208',
  ),
  'MKD' => 
  array (
    0 => 'Denar',
    1 => '807',
  ),
  'DJF' => 
  array (
    0 => 'Djibouti Franc',
    1 => '262',
  ),
  'STD' => 
  array (
    0 => 'Dobra',
    1 => '678',
  ),
  'DOP' => 
  array (
    0 => 'Dominican Peso',
    1 => '214',
  ),
  'VND' => 
  array (
    0 => 'Dong',
    1 => '704',
  ),
  'XCD' => 
  array (
    0 => 'East Caribbean Dollar',
    1 => '951',
  ),
  'EGP' => 
  array (
    0 => 'Egyptian Pound',
    1 => '818',
  ),
  'SVC' => 
  array (
    0 => 'El Salvador Colon',
    1 => '222',
  ),
  'ETB' => 
  array (
    0 => 'Ethiopian Birr',
    1 => '230',
  ),
  'EUR' => 
  array (
    0 => 'Euro',
    1 => '978',
  ),
  'FKP' => 
  array (
    0 => 'Falkland Islands Pound',
    1 => '238',
  ),
  'FJD' => 
  array (
    0 => 'Fiji Dollar',
    1 => '242',
  ),
  'HUF' => 
  array (
    0 => 'Forint',
    1 => '348',
  ),
  'GHS' => 
  array (
    0 => 'Ghana Cedi',
    1 => '936',
  ),
  'GIP' => 
  array (
    0 => 'Gibraltar Pound',
    1 => '292',
  ),
  'HTG' => 
  array (
    0 => 'Gourde',
    1 => '332',
  ),
  'PYG' => 
  array (
    0 => 'Guarani',
    1 => '600',
  ),
  'GNF' => 
  array (
    0 => 'Guinea Franc',
    1 => '324',
  ),
  'GYD' => 
  array (
    0 => 'Guyana Dollar',
    1 => '328',
  ),
  'HKD' => 
  array (
    0 => 'Hong Kong Dollar',
    1 => '344',
  ),
  'UAH' => 
  array (
    0 => 'Hryvnia',
    1 => '980',
  ),
  'ISK' => 
  array (
    0 => 'Iceland Krona',
    1 => '352',
  ),
  'INR' => 
  array (
    0 => 'Indian Rupee',
    1 => '356',
  ),
  'IRR' => 
  array (
    0 => 'Iranian Rial',
    1 => '364',
  ),
  'IQD' => 
  array (
    0 => 'Iraqi Dinar',
    1 => '368',
  ),
  'JMD' => 
  array (
    0 => 'Jamaican Dollar',
    1 => '388',
  ),
  'JOD' => 
  array (
    0 => 'Jordanian Dinar',
    1 => '400',
  ),
  'KES' => 
  array (
    0 => 'Kenyan Shilling',
    1 => '404',
  ),
  'PGK' => 
  array (
    0 => 'Kina',
    1 => '598',
  ),
  'LAK' => 
  array (
    0 => 'Kip',
    1 => '418',
  ),
  'HRK' => 
  array (
    0 => 'Kuna',
    1 => '191',
  ),
  'KWD' => 
  array (
    0 => 'Kuwaiti Dinar',
    1 => '414',
  ),
  'AOA' => 
  array (
    0 => 'Kwanza',
    1 => '973',
  ),
  'MMK' => 
  array (
    0 => 'Kyat',
    1 => '104',
  ),
  'GEL' => 
  array (
    0 => 'Lari',
    1 => '981',
  ),
  'LBP' => 
  array (
    0 => 'Lebanese Pound',
    1 => '422',
  ),
  'ALL' => 
  array (
    0 => 'Lek',
    1 => '008',
  ),
  'HNL' => 
  array (
    0 => 'Lempira',
    1 => '340',
  ),
  'SLL' => 
  array (
    0 => 'Leone',
    1 => '694',
  ),
  'LRD' => 
  array (
    0 => 'Liberian Dollar',
    1 => '430',
  ),
  'LYD' => 
  array (
    0 => 'Libyan Dinar',
    1 => '434',
  ),
  'SZL' => 
  array (
    0 => 'Lilangeni',
    1 => '748',
  ),
  'LSL' => 
  array (
    0 => 'Loti',
    1 => '426',
  ),
  'MGA' => 
  array (
    0 => 'Malagasy Ariary',
    1 => '969',
  ),
  'MWK' => 
  array (
    0 => 'Malawi Kwacha',
    1 => '454',
  ),
  'MYR' => 
  array (
    0 => 'Malaysian Ringgit',
    1 => '458',
  ),
  'MUR' => 
  array (
    0 => 'Mauritius Rupee',
    1 => '480',
  ),
  'MXN' => 
  array (
    0 => 'Mexican Peso',
    1 => '484',
  ),
  'MDL' => 
  array (
    0 => 'Moldovan Leu',
    1 => '498',
  ),
  'MAD' => 
  array (
    0 => 'Moroccan Dirham',
    1 => '504',
  ),
  'MZN' => 
  array (
    0 => 'Mozambique Metical',
    1 => '943',
  ),
  'NGN' => 
  array (
    0 => 'Naira',
    1 => '566',
  ),
  'ERN' => 
  array (
    0 => 'Nakfa',
    1 => '232',
  ),
  'NAD' => 
  array (
    0 => 'Namibia Dollar',
    1 => '516',
  ),
  'NPR' => 
  array (
    0 => 'Nepalese Rupee',
    1 => '524',
  ),
  'ANG' => 
  array (
    0 => 'Netherlands Antillean Guilder',
    1 => '532',
  ),
  'ILS' => 
  array (
    0 => 'New Israeli Sheqel',
    1 => '376',
  ),
  'TWD' => 
  array (
    0 => 'New Taiwan Dollar',
    1 => '901',
  ),
  'NZD' => 
  array (
    0 => 'New Zealand Dollar',
    1 => '554',
  ),
  'BTN' => 
  array (
    0 => 'Ngultrum',
    1 => '064',
  ),
  'KPW' => 
  array (
    0 => 'North Korean Won',
    1 => '408',
  ),
  'NOK' => 
  array (
    0 => 'Norwegian Krone',
    1 => '578',
  ),
  'MRO' => 
  array (
    0 => 'Ouguiya',
    1 => '478',
  ),
  'TOP' => 
  array (
    0 => 'Pa\'anga',
    1 => '776',
  ),
  'PKR' => 
  array (
    0 => 'Pakistan Rupee',
    1 => '586',
  ),
  'MOP' => 
  array (
    0 => 'Pataca',
    1 => '446',
  ),
  'CUC' => 
  array (
    0 => 'Peso Convertible',
    1 => '931',
  ),
  'UYU' => 
  array (
    0 => 'Peso Uruguayo',
    1 => '858',
  ),
  'PHP' => 
  array (
    0 => 'Philippine Peso',
    1 => '608',
  ),
  'GBP' => 
  array (
    0 => 'Pound Sterling',
    1 => '826',
  ),
  'BWP' => 
  array (
    0 => 'Pula',
    1 => '072',
  ),
  'QAR' => 
  array (
    0 => 'Qatari Rial',
    1 => '634',
  ),
  'GTQ' => 
  array (
    0 => 'Quetzal',
    1 => '320',
  ),
  'ZAR' => 
  array (
    0 => 'Rand',
    1 => '710',
  ),
  'OMR' => 
  array (
    0 => 'Rial Omani',
    1 => '512',
  ),
  'KHR' => 
  array (
    0 => 'Riel',
    1 => '116',
  ),
  'RON' => 
  array (
    0 => 'Romanian Leu',
    1 => '946',
  ),
  'MVR' => 
  array (
    0 => 'Rufiyaa',
    1 => '462',
  ),
  'IDR' => 
  array (
    0 => 'Rupiah',
    1 => '360',
  ),
  'RUB' => 
  array (
    0 => 'Russian Ruble',
    1 => '643',
  ),
  'RWF' => 
  array (
    0 => 'Rwanda Franc',
    1 => '646',
  ),
  'SHP' => 
  array (
    0 => 'Saint Helena Pound',
    1 => '654',
  ),
  'SAR' => 
  array (
    0 => 'Saudi Riyal',
    1 => '682',
  ),
  'RSD' => 
  array (
    0 => 'Serbian Dinar',
    1 => '941',
  ),
  'SCR' => 
  array (
    0 => 'Seychelles Rupee',
    1 => '690',
  ),
  'SGD' => 
  array (
    0 => 'Singapore Dollar',
    1 => '702',
  ),
  'PEN' => 
  array (
    0 => 'Sol',
    1 => '604',
  ),
  'SBD' => 
  array (
    0 => 'Solomon Islands Dollar',
    1 => '090',
  ),
  'KGS' => 
  array (
    0 => 'Som',
    1 => '417',
  ),
  'SOS' => 
  array (
    0 => 'Somali Shilling',
    1 => '706',
  ),
  'TJS' => 
  array (
    0 => 'Somoni',
    1 => '972',
  ),
  'SSP' => 
  array (
    0 => 'South Sudanese Pound',
    1 => '728',
  ),
  'LKR' => 
  array (
    0 => 'Sri Lanka Rupee',
    1 => '144',
  ),
  'SDG' => 
  array (
    0 => 'Sudanese Pound',
    1 => '938',
  ),
  'SRD' => 
  array (
    0 => 'Surinam Dollar',
    1 => '968',
  ),
  'SEK' => 
  array (
    0 => 'Swedish Krona',
    1 => '752',
  ),
  'CHF' => 
  array (
    0 => 'Swiss Franc',
    1 => '756',
  ),
  'SYP' => 
  array (
    0 => 'Syrian Pound',
    1 => '760',
  ),
  'BDT' => 
  array (
    0 => 'Taka',
    1 => '050',
  ),
  'WST' => 
  array (
    0 => 'Tala',
    1 => '882',
  ),
  'TZS' => 
  array (
    0 => 'Tanzanian Shilling',
    1 => '834',
  ),
  'KZT' => 
  array (
    0 => 'Tenge',
    1 => '398',
  ),
  'TTD' => 
  array (
    0 => 'Trinidad and Tobago Dollar',
    1 => '780',
  ),
  'MNT' => 
  array (
    0 => 'Tugrik',
    1 => '496',
  ),
  'TND' => 
  array (
    0 => 'Tunisian Dinar',
    1 => '788',
  ),
  'TRY' => 
  array (
    0 => 'Turkish lira',
    1 => '949',
  ),
  'TMT' => 
  array (
    0 => 'Turkmenistan New Manat',
    1 => '934',
  ),
  'AED' => 
  array (
    0 => 'UAE Dirham',
    1 => '784',
  ),
  'USD' => 
  array (
    0 => 'US dollar',
    1 => '840',
  ),
  'UGX' => 
  array (
    0 => 'Uganda Shilling',
    1 => '800',
  ),
  'UZS' => 
  array (
    0 => 'Uzbekistan Sum',
    1 => '860',
  ),
  'VUV' => 
  array (
    0 => 'Vatu',
    1 => '548',
  ),
  'KRW' => 
  array (
    0 => 'Won',
    1 => '410',
  ),
  'YER' => 
  array (
    0 => 'Yemeni Rial',
    1 => '886',
  ),
  'JPY' => 
  array (
    0 => 'Yen',
    1 => '392',
  ),
  'CNY' => 
  array (
    0 => 'Yuan Renminbi',
    1 => '156',
  ),
  'ZMW' => 
  array (
    0 => 'Zambian Kwacha',
    1 => '967',
  ),
  'ZWL' => 
  array (
    0 => 'Zimbabwe Dollar',
    1 => '932',
  ),
  'PLN' => 
  array (
    0 => 'Zloty',
    1 => '985',
  ),
); ?>