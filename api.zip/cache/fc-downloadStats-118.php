<?php return array (
  118 => 
  array (
    0 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '71',
      'representation_id' => '71',
      2 => '5',
      'metric' => '5',
    ),
    1 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '71',
      'representation_id' => '71',
      2 => '8',
      'metric' => '8',
    ),
    2 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '71',
      'representation_id' => '71',
      2 => '22',
      'metric' => '22',
    ),
    3 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '71',
      'representation_id' => '71',
      2 => '67',
      'metric' => '67',
    ),
    4 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '71',
      'representation_id' => '71',
      2 => '140',
      'metric' => '140',
    ),
    5 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '71',
      'representation_id' => '71',
      2 => '156',
      'metric' => '156',
    ),
    6 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '71',
      'representation_id' => '71',
      2 => '129',
      'metric' => '129',
    ),
    7 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '71',
      'representation_id' => '71',
      2 => '79',
      'metric' => '79',
    ),
    8 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '71',
      'representation_id' => '71',
      2 => '269',
      'metric' => '269',
    ),
    9 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '71',
      'representation_id' => '71',
      2 => '99',
      'metric' => '99',
    ),
    10 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '71',
      'representation_id' => '71',
      2 => '64',
      'metric' => '64',
    ),
    11 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '71',
      'representation_id' => '71',
      2 => '56',
      'metric' => '56',
    ),
    12 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '71',
      'representation_id' => '71',
      2 => '44',
      'metric' => '44',
    ),
    13 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '71',
      'representation_id' => '71',
      2 => '93',
      'metric' => '93',
    ),
    14 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '71',
      'representation_id' => '71',
      2 => '4',
      'metric' => '4',
    ),
  ),
); ?>