<?php return array (
  52 => 
  array (
    0 => 
    array (
      0 => '202202',
      'month' => '202202',
      1 => '42',
      'representation_id' => '42',
      2 => '1',
      'metric' => '1',
    ),
    1 => 
    array (
      0 => '202203',
      'month' => '202203',
      1 => '42',
      'representation_id' => '42',
      2 => '10',
      'metric' => '10',
    ),
    2 => 
    array (
      0 => '202204',
      'month' => '202204',
      1 => '42',
      'representation_id' => '42',
      2 => '12',
      'metric' => '12',
    ),
    3 => 
    array (
      0 => '202205',
      'month' => '202205',
      1 => '42',
      'representation_id' => '42',
      2 => '8',
      'metric' => '8',
    ),
    4 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '42',
      'representation_id' => '42',
      2 => '26',
      'metric' => '26',
    ),
    5 => 
    array (
      0 => '202207',
      'month' => '202207',
      1 => '42',
      'representation_id' => '42',
      2 => '8',
      'metric' => '8',
    ),
    6 => 
    array (
      0 => '202208',
      'month' => '202208',
      1 => '42',
      'representation_id' => '42',
      2 => '3',
      'metric' => '3',
    ),
    7 => 
    array (
      0 => '202209',
      'month' => '202209',
      1 => '42',
      'representation_id' => '42',
      2 => '10',
      'metric' => '10',
    ),
    8 => 
    array (
      0 => '202210',
      'month' => '202210',
      1 => '42',
      'representation_id' => '42',
      2 => '10',
      'metric' => '10',
    ),
    9 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '42',
      'representation_id' => '42',
      2 => '22',
      'metric' => '22',
    ),
    10 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '42',
      'representation_id' => '42',
      2 => '3',
      'metric' => '3',
    ),
    11 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '42',
      'representation_id' => '42',
      2 => '6',
      'metric' => '6',
    ),
    12 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '42',
      'representation_id' => '42',
      2 => '7',
      'metric' => '7',
    ),
    13 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '42',
      'representation_id' => '42',
      2 => '10',
      'metric' => '10',
    ),
    14 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '42',
      'representation_id' => '42',
      2 => '6',
      'metric' => '6',
    ),
    15 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '42',
      'representation_id' => '42',
      2 => '14',
      'metric' => '14',
    ),
    16 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '42',
      'representation_id' => '42',
      2 => '16',
      'metric' => '16',
    ),
    17 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '42',
      'representation_id' => '42',
      2 => '17',
      'metric' => '17',
    ),
    18 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '42',
      'representation_id' => '42',
      2 => '1',
      'metric' => '1',
    ),
    19 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '42',
      'representation_id' => '42',
      2 => '7',
      'metric' => '7',
    ),
    20 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '42',
      'representation_id' => '42',
      2 => '23',
      'metric' => '23',
    ),
    21 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '42',
      'representation_id' => '42',
      2 => '19',
      'metric' => '19',
    ),
    22 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '42',
      'representation_id' => '42',
      2 => '9',
      'metric' => '9',
    ),
    23 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '42',
      'representation_id' => '42',
      2 => '14',
      'metric' => '14',
    ),
    24 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '42',
      'representation_id' => '42',
      2 => '17',
      'metric' => '17',
    ),
    25 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '42',
      'representation_id' => '42',
      2 => '7',
      'metric' => '7',
    ),
    26 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '42',
      'representation_id' => '42',
      2 => '13',
      'metric' => '13',
    ),
    27 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '42',
      'representation_id' => '42',
      2 => '12',
      'metric' => '12',
    ),
    28 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '42',
      'representation_id' => '42',
      2 => '9',
      'metric' => '9',
    ),
    29 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '42',
      'representation_id' => '42',
      2 => '4',
      'metric' => '4',
    ),
    30 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '42',
      'representation_id' => '42',
      2 => '11',
      'metric' => '11',
    ),
    31 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '42',
      'representation_id' => '42',
      2 => '17',
      'metric' => '17',
    ),
    32 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '42',
      'representation_id' => '42',
      2 => '10',
      'metric' => '10',
    ),
    33 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '42',
      'representation_id' => '42',
      2 => '16',
      'metric' => '16',
    ),
    34 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '42',
      'representation_id' => '42',
      2 => '9',
      'metric' => '9',
    ),
    35 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '42',
      'representation_id' => '42',
      2 => '1',
      'metric' => '1',
    ),
    36 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '42',
      'representation_id' => '42',
      2 => '6',
      'metric' => '6',
    ),
    37 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '42',
      'representation_id' => '42',
      2 => '7',
      'metric' => '7',
    ),
    38 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '42',
      'representation_id' => '42',
      2 => '14',
      'metric' => '14',
    ),
    39 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '42',
      'representation_id' => '42',
      2 => '13',
      'metric' => '13',
    ),
    40 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '42',
      'representation_id' => '42',
      2 => '9',
      'metric' => '9',
    ),
    41 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '42',
      'representation_id' => '42',
      2 => '11',
      'metric' => '11',
    ),
    42 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '42',
      'representation_id' => '42',
      2 => '2',
      'metric' => '2',
    ),
  ),
); ?>