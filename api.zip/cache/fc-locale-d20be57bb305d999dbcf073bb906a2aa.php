<?php return array (
  'plugins.block.information.displayName' => 'Information Block',
  'plugins.block.information.description' => 'This plugin provides sidebar information link.',
  'plugins.block.information.link' => 'Information',
); ?>