<?php return array (
  'plugins.OAIMetadata.marc.displayName' => 'MARC Metadata Format',
  'plugins.OAIMetadata.marc.description' => 'Structures metadata in a way that is consistent with the MARC format.',
); ?>