<?php return array (
  'chartType' => 'bar',
  'datasetMaxCount' => '4',
  'displayStatistics' => true,
); ?>