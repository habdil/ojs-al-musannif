<?php return array (
  130 => 
  array (
    0 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '74',
      'representation_id' => '74',
      2 => '5',
      'metric' => '5',
    ),
    1 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '74',
      'representation_id' => '74',
      2 => '23',
      'metric' => '23',
    ),
    2 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '74',
      'representation_id' => '74',
      2 => '13',
      'metric' => '13',
    ),
    3 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '74',
      'representation_id' => '74',
      2 => '13',
      'metric' => '13',
    ),
    4 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '74',
      'representation_id' => '74',
      2 => '6',
      'metric' => '6',
    ),
  ),
); ?>