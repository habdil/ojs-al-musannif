<?php return array (
  110 => 
  array (
    0 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '64',
      'representation_id' => '64',
      2 => '5',
      'metric' => '5',
    ),
    1 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '64',
      'representation_id' => '64',
      2 => '11',
      'metric' => '11',
    ),
    2 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '64',
      'representation_id' => '64',
      2 => '6',
      'metric' => '6',
    ),
    3 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '64',
      'representation_id' => '64',
      2 => '9',
      'metric' => '9',
    ),
    4 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '64',
      'representation_id' => '64',
      2 => '13',
      'metric' => '13',
    ),
    5 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '64',
      'representation_id' => '64',
      2 => '73',
      'metric' => '73',
    ),
    6 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '64',
      'representation_id' => '64',
      2 => '10',
      'metric' => '10',
    ),
    7 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '64',
      'representation_id' => '64',
      2 => '7',
      'metric' => '7',
    ),
    8 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '64',
      'representation_id' => '64',
      2 => '11',
      'metric' => '11',
    ),
    9 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '64',
      'representation_id' => '64',
      2 => '10',
      'metric' => '10',
    ),
    10 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '64',
      'representation_id' => '64',
      2 => '12',
      'metric' => '12',
    ),
    11 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '64',
      'representation_id' => '64',
      2 => '9',
      'metric' => '9',
    ),
    12 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '64',
      'representation_id' => '64',
      2 => '10',
      'metric' => '10',
    ),
    13 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '64',
      'representation_id' => '64',
      2 => '3',
      'metric' => '3',
    ),
    14 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '64',
      'representation_id' => '64',
      2 => '2',
      'metric' => '2',
    ),
    15 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '64',
      'representation_id' => '64',
      2 => '3',
      'metric' => '3',
    ),
    16 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '64',
      'representation_id' => '64',
      2 => '3',
      'metric' => '3',
    ),
    17 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '64',
      'representation_id' => '64',
      2 => '11',
      'metric' => '11',
    ),
    18 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '64',
      'representation_id' => '64',
      2 => '4',
      'metric' => '4',
    ),
    19 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '64',
      'representation_id' => '64',
      2 => '5',
      'metric' => '5',
    ),
    20 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '64',
      'representation_id' => '64',
      2 => '4',
      'metric' => '4',
    ),
  ),
); ?>