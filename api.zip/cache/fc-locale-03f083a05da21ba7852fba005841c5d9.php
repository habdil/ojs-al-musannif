<?php return array (
  'plugins.generic.customBlockManager.displayName' => 'Blok Manager Umum',
  'plugins.generic.customBlockManager.blockName' => 'Nama Blok',
  'plugins.generic.customBlockManager.addBlock' => 'Tambah Blok',
  'plugins.generic.customBlock.content' => 'Konten',
  'plugins.generic.customBlock.nameSuffix' => '(Plugin Custom Block)',
  'plugins.generic.customBlock.description' => 'Ini adalah user-generated block.',
); ?>