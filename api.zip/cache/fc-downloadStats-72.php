<?php return array (
  72 => 
  array (
    0 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '52',
      'representation_id' => '52',
      2 => '10',
      'metric' => '10',
    ),
    1 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '52',
      'representation_id' => '52',
      2 => '21',
      'metric' => '21',
    ),
    2 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '52',
      'representation_id' => '52',
      2 => '18',
      'metric' => '18',
    ),
    3 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '52',
      'representation_id' => '52',
      2 => '8',
      'metric' => '8',
    ),
    4 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '52',
      'representation_id' => '52',
      2 => '41',
      'metric' => '41',
    ),
    5 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '52',
      'representation_id' => '52',
      2 => '44',
      'metric' => '44',
    ),
    6 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '52',
      'representation_id' => '52',
      2 => '5',
      'metric' => '5',
    ),
    7 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '52',
      'representation_id' => '52',
      2 => '3',
      'metric' => '3',
    ),
    8 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '52',
      'representation_id' => '52',
      2 => '3',
      'metric' => '3',
    ),
    9 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '52',
      'representation_id' => '52',
      2 => '8',
      'metric' => '8',
    ),
    10 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '52',
      'representation_id' => '52',
      2 => '4',
      'metric' => '4',
    ),
    11 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '52',
      'representation_id' => '52',
      2 => '6',
      'metric' => '6',
    ),
    12 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '52',
      'representation_id' => '52',
      2 => '3',
      'metric' => '3',
    ),
    13 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '52',
      'representation_id' => '52',
      2 => '10',
      'metric' => '10',
    ),
    14 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '52',
      'representation_id' => '52',
      2 => '11',
      'metric' => '11',
    ),
    15 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '52',
      'representation_id' => '52',
      2 => '2',
      'metric' => '2',
    ),
    16 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '52',
      'representation_id' => '52',
      2 => '14',
      'metric' => '14',
    ),
    17 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '52',
      'representation_id' => '52',
      2 => '12',
      'metric' => '12',
    ),
    18 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '52',
      'representation_id' => '52',
      2 => '9',
      'metric' => '9',
    ),
    19 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '52',
      'representation_id' => '52',
      2 => '46',
      'metric' => '46',
    ),
    20 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '52',
      'representation_id' => '52',
      2 => '71',
      'metric' => '71',
    ),
    21 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '52',
      'representation_id' => '52',
      2 => '63',
      'metric' => '63',
    ),
    22 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '52',
      'representation_id' => '52',
      2 => '23',
      'metric' => '23',
    ),
    23 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '52',
      'representation_id' => '52',
      2 => '48',
      'metric' => '48',
    ),
    24 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '52',
      'representation_id' => '52',
      2 => '25',
      'metric' => '25',
    ),
    25 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '52',
      'representation_id' => '52',
      2 => '46',
      'metric' => '46',
    ),
    26 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '52',
      'representation_id' => '52',
      2 => '39',
      'metric' => '39',
    ),
    27 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '52',
      'representation_id' => '52',
      2 => '77',
      'metric' => '77',
    ),
    28 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '52',
      'representation_id' => '52',
      2 => '25',
      'metric' => '25',
    ),
    29 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '52',
      'representation_id' => '52',
      2 => '25',
      'metric' => '25',
    ),
    30 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '52',
      'representation_id' => '52',
      2 => '29',
      'metric' => '29',
    ),
    31 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '52',
      'representation_id' => '52',
      2 => '2',
      'metric' => '2',
    ),
  ),
); ?>