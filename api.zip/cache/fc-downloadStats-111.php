<?php return array (
  111 => 
  array (
    0 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '85',
      'representation_id' => '85',
      2 => '1',
      'metric' => '1',
    ),
    1 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '85',
      'representation_id' => '85',
      2 => '12',
      'metric' => '12',
    ),
    2 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '85',
      'representation_id' => '85',
      2 => '8',
      'metric' => '8',
    ),
  ),
); ?>