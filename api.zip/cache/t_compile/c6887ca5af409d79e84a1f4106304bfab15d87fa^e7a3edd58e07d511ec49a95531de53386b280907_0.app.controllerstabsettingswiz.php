<?php
/* Smarty version 3.1.33, created on 2025-09-02 09:32:56
  from 'app:controllerstabsettingswiz' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_68b6b9c812fa64_19866118',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e7a3edd58e07d511ec49a95531de53386b280907' => 
    array (
      0 => 'app:controllerstabsettingswiz',
      1 => 1551386984,
      2 => 'app',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_68b6b9c812fa64_19866118 (Smarty_Internal_Template $_smarty_tpl) {
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['fbvElement'][0], array( array('type'=>"hidden",'id'=>"wizardMode",'name'=>"wizardMode",'value'=>$_smarty_tpl->tpl_vars['wizardMode']->value),$_smarty_tpl ) );?>

<?php }
}
