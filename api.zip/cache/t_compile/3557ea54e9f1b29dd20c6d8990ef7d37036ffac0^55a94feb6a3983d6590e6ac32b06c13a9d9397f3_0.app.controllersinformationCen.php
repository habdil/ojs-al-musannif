<?php
/* Smarty version 3.1.33, created on 2025-06-29 08:26:33
  from 'app:controllersinformationCen' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_6860f8b97ccd32_84058121',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55a94feb6a3983d6590e6ac32b06c13a9d9397f3' => 
    array (
      0 => 'app:controllersinformationCen',
      1 => 1551386984,
      2 => 'app',
    ),
  ),
  'includes' => 
  array (
    'app:linkAction/buttonConfirmationLinkAction.tpl' => 1,
    'app:linkAction/linkAction.tpl' => 1,
    'app:controllers/revealMore.tpl' => 1,
  ),
),false)) {
function content_6860f8b97ccd32_84058121 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/home/mtsddici/jurnal.mtsddicilellang.sch.id/lib/pkp/lib/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>

<?php $_smarty_tpl->_assignInScope('noteId', $_smarty_tpl->tpl_vars['note']->value->getId());
$_smarty_tpl->_assignInScope('formId', "deleteNoteForm-".((string)$_smarty_tpl->tpl_vars['noteId']->value));?>

<?php echo '<script'; ?>
 type="text/javascript">
	$(function() {
			// Attach the form handler.
			$('#<?php echo $_smarty_tpl->tpl_vars['formId']->value;?>
').pkpHandler('$.pkp.controllers.form.AjaxFormHandler', {
				baseUrl: <?php echo json_encode($_smarty_tpl->tpl_vars['baseUrl']->value);?>

			});
	});
<?php echo '</script'; ?>
>

<div id="note-<?php echo $_smarty_tpl->tpl_vars['noteId']->value;?>
" class="note<?php if ($_smarty_tpl->tpl_vars['noteViewStatus']->value == @constant('RECORD_VIEW_RESULT_INSERTED')) {?> new<?php }?>">
	<div class="details">
		<span class="user">
			<?php $_smarty_tpl->_assignInScope('noteUser', $_smarty_tpl->tpl_vars['note']->value->getUser());?>
			<?php echo call_user_func_array($_smarty_tpl->registered_plugins[ 'modifier' ][ 'escape' ][ 0 ], array( $_smarty_tpl->tpl_vars['noteUser']->value->getFullName() ));?>

		</span>
		<span class="date">
			<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['note']->value->getDateCreated(),$_smarty_tpl->tpl_vars['datetimeFormatShort']->value);?>

		</span>
		<?php if (($_smarty_tpl->tpl_vars['notesDeletable']->value && array_intersect(array(ROLE_ID_MANAGER,ROLE_ID_SUB_EDITOR),(array)$_smarty_tpl->tpl_vars['userRoles']->value))) {?>
			<div class="actions">
				<?php if ($_smarty_tpl->tpl_vars['notesDeletable']->value && array_intersect(array(ROLE_ID_MANAGER,ROLE_ID_SUB_EDITOR),(array)$_smarty_tpl->tpl_vars['userRoles']->value)) {?>
					<form class="pkp_form" id="<?php echo $_smarty_tpl->tpl_vars['formId']->value;?>
" action="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('op'=>"deleteNote",'noteId'=>$_smarty_tpl->tpl_vars['noteId']->value,'params'=>$_smarty_tpl->tpl_vars['linkParams']->value),$_smarty_tpl ) );?>
">
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['csrf'][0], array( array(),$_smarty_tpl ) );?>

						<?php $_smarty_tpl->_assignInScope('deleteNoteButtonId', "deleteNote-".((string)$_smarty_tpl->tpl_vars['noteId']->value));?>
						<?php $_smarty_tpl->_subTemplateRender("app:linkAction/buttonConfirmationLinkAction.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('titleIcon'=>"modal_delete",'buttonSelector'=>"#".((string)$_smarty_tpl->tpl_vars['deleteNoteButtonId']->value),'dialogText'=>"informationCenter.deleteConfirm"), 0, false);
?>
						<button type="submit" id="<?php echo $_smarty_tpl->tpl_vars['deleteNoteButtonId']->value;?>
" class="pkp_button pkp_button_offset"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['translate'][0], array( array('key'=>'common.delete'),$_smarty_tpl ) );?>
</button>
					</form>
				<?php }?>
			</div>
		<?php }?>
	</div>
	<div class="message">
		<?php if ($_smarty_tpl->tpl_vars['noteFileDownloadLink']->value) {?>
			<?php $_smarty_tpl->_subTemplateRender("app:linkAction/linkAction.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('action'=>$_smarty_tpl->tpl_vars['noteFileDownloadLink']->value,'contextId'=>$_smarty_tpl->tpl_vars['note']->value->getId()), 0, false);
?>
		<?php }?>
		<?php $_smarty_tpl->_subTemplateRender("app:controllers/revealMore.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('content'=>call_user_func_array($_smarty_tpl->registered_plugins[ 'modifier' ][ 'strip_unsafe_html' ][ 0 ], array( $_smarty_tpl->tpl_vars['note']->value->getContents() ))), 0, false);
?>
	</div>
</div>
<?php }
}
