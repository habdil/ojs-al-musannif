<?php return array (
  'plugins.themes.defaultManuscript.name' => 'Manuscript (Default child theme)',
  'plugins.themes.defaultManuscript.description' => 'A clean, simple theme with a boxed layout that mimics a paper document.',
  'plugins.themes.defaultManuscript.option.typography.montserrat_notoSerif' => 'Montserrat/Noto Serif',
  'plugins.themes.defaultManuscript.option.accentColour.label' => 'Accent Colour',
); ?>