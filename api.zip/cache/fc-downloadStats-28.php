<?php return array (
  28 => 
  array (
    0 => 
    array (
      0 => '201911',
      'month' => '201911',
      1 => '12',
      'representation_id' => '12',
      2 => '1',
      'metric' => '1',
    ),
    1 => 
    array (
      0 => '201912',
      'month' => '201912',
      1 => '12',
      'representation_id' => '12',
      2 => '6',
      'metric' => '6',
    ),
    2 => 
    array (
      0 => '202001',
      'month' => '202001',
      1 => '12',
      'representation_id' => '12',
      2 => '24',
      'metric' => '24',
    ),
    3 => 
    array (
      0 => '202002',
      'month' => '202002',
      1 => '12',
      'representation_id' => '12',
      2 => '31',
      'metric' => '31',
    ),
    4 => 
    array (
      0 => '202003',
      'month' => '202003',
      1 => '12',
      'representation_id' => '12',
      2 => '63',
      'metric' => '63',
    ),
    5 => 
    array (
      0 => '202004',
      'month' => '202004',
      1 => '12',
      'representation_id' => '12',
      2 => '47',
      'metric' => '47',
    ),
    6 => 
    array (
      0 => '202005',
      'month' => '202005',
      1 => '12',
      'representation_id' => '12',
      2 => '32',
      'metric' => '32',
    ),
    7 => 
    array (
      0 => '202006',
      'month' => '202006',
      1 => '12',
      'representation_id' => '12',
      2 => '23',
      'metric' => '23',
    ),
    8 => 
    array (
      0 => '202007',
      'month' => '202007',
      1 => '12',
      'representation_id' => '12',
      2 => '19',
      'metric' => '19',
    ),
    9 => 
    array (
      0 => '202008',
      'month' => '202008',
      1 => '12',
      'representation_id' => '12',
      2 => '14',
      'metric' => '14',
    ),
    10 => 
    array (
      0 => '202009',
      'month' => '202009',
      1 => '12',
      'representation_id' => '12',
      2 => '13',
      'metric' => '13',
    ),
    11 => 
    array (
      0 => '202010',
      'month' => '202010',
      1 => '12',
      'representation_id' => '12',
      2 => '29',
      'metric' => '29',
    ),
    12 => 
    array (
      0 => '202011',
      'month' => '202011',
      1 => '12',
      'representation_id' => '12',
      2 => '37',
      'metric' => '37',
    ),
    13 => 
    array (
      0 => '202012',
      'month' => '202012',
      1 => '12',
      'representation_id' => '12',
      2 => '50',
      'metric' => '50',
    ),
    14 => 
    array (
      0 => '202101',
      'month' => '202101',
      1 => '12',
      'representation_id' => '12',
      2 => '11',
      'metric' => '11',
    ),
    15 => 
    array (
      0 => '202102',
      'month' => '202102',
      1 => '12',
      'representation_id' => '12',
      2 => '7',
      'metric' => '7',
    ),
    16 => 
    array (
      0 => '202103',
      'month' => '202103',
      1 => '12',
      'representation_id' => '12',
      2 => '13',
      'metric' => '13',
    ),
    17 => 
    array (
      0 => '202104',
      'month' => '202104',
      1 => '12',
      'representation_id' => '12',
      2 => '11',
      'metric' => '11',
    ),
    18 => 
    array (
      0 => '202105',
      'month' => '202105',
      1 => '12',
      'representation_id' => '12',
      2 => '16',
      'metric' => '16',
    ),
    19 => 
    array (
      0 => '202106',
      'month' => '202106',
      1 => '12',
      'representation_id' => '12',
      2 => '14',
      'metric' => '14',
    ),
    20 => 
    array (
      0 => '202107',
      'month' => '202107',
      1 => '12',
      'representation_id' => '12',
      2 => '28',
      'metric' => '28',
    ),
    21 => 
    array (
      0 => '202108',
      'month' => '202108',
      1 => '12',
      'representation_id' => '12',
      2 => '26',
      'metric' => '26',
    ),
    22 => 
    array (
      0 => '202109',
      'month' => '202109',
      1 => '12',
      'representation_id' => '12',
      2 => '58',
      'metric' => '58',
    ),
    23 => 
    array (
      0 => '202110',
      'month' => '202110',
      1 => '12',
      'representation_id' => '12',
      2 => '80',
      'metric' => '80',
    ),
    24 => 
    array (
      0 => '202111',
      'month' => '202111',
      1 => '12',
      'representation_id' => '12',
      2 => '92',
      'metric' => '92',
    ),
    25 => 
    array (
      0 => '202112',
      'month' => '202112',
      1 => '12',
      'representation_id' => '12',
      2 => '32',
      'metric' => '32',
    ),
    26 => 
    array (
      0 => '202201',
      'month' => '202201',
      1 => '12',
      'representation_id' => '12',
      2 => '27',
      'metric' => '27',
    ),
    27 => 
    array (
      0 => '202202',
      'month' => '202202',
      1 => '12',
      'representation_id' => '12',
      2 => '47',
      'metric' => '47',
    ),
    28 => 
    array (
      0 => '202203',
      'month' => '202203',
      1 => '12',
      'representation_id' => '12',
      2 => '49',
      'metric' => '49',
    ),
    29 => 
    array (
      0 => '202204',
      'month' => '202204',
      1 => '12',
      'representation_id' => '12',
      2 => '29',
      'metric' => '29',
    ),
    30 => 
    array (
      0 => '202205',
      'month' => '202205',
      1 => '12',
      'representation_id' => '12',
      2 => '15',
      'metric' => '15',
    ),
    31 => 
    array (
      0 => '202206',
      'month' => '202206',
      1 => '12',
      'representation_id' => '12',
      2 => '46',
      'metric' => '46',
    ),
    32 => 
    array (
      0 => '202207',
      'month' => '202207',
      1 => '12',
      'representation_id' => '12',
      2 => '40',
      'metric' => '40',
    ),
    33 => 
    array (
      0 => '202208',
      'month' => '202208',
      1 => '12',
      'representation_id' => '12',
      2 => '26',
      'metric' => '26',
    ),
    34 => 
    array (
      0 => '202209',
      'month' => '202209',
      1 => '12',
      'representation_id' => '12',
      2 => '18',
      'metric' => '18',
    ),
    35 => 
    array (
      0 => '202210',
      'month' => '202210',
      1 => '12',
      'representation_id' => '12',
      2 => '35',
      'metric' => '35',
    ),
    36 => 
    array (
      0 => '202211',
      'month' => '202211',
      1 => '12',
      'representation_id' => '12',
      2 => '37',
      'metric' => '37',
    ),
    37 => 
    array (
      0 => '202212',
      'month' => '202212',
      1 => '12',
      'representation_id' => '12',
      2 => '39',
      'metric' => '39',
    ),
    38 => 
    array (
      0 => '202301',
      'month' => '202301',
      1 => '12',
      'representation_id' => '12',
      2 => '23',
      'metric' => '23',
    ),
    39 => 
    array (
      0 => '202302',
      'month' => '202302',
      1 => '12',
      'representation_id' => '12',
      2 => '25',
      'metric' => '25',
    ),
    40 => 
    array (
      0 => '202303',
      'month' => '202303',
      1 => '12',
      'representation_id' => '12',
      2 => '43',
      'metric' => '43',
    ),
    41 => 
    array (
      0 => '202304',
      'month' => '202304',
      1 => '12',
      'representation_id' => '12',
      2 => '30',
      'metric' => '30',
    ),
    42 => 
    array (
      0 => '202305',
      'month' => '202305',
      1 => '12',
      'representation_id' => '12',
      2 => '24',
      'metric' => '24',
    ),
    43 => 
    array (
      0 => '202306',
      'month' => '202306',
      1 => '12',
      'representation_id' => '12',
      2 => '32',
      'metric' => '32',
    ),
    44 => 
    array (
      0 => '202307',
      'month' => '202307',
      1 => '12',
      'representation_id' => '12',
      2 => '24',
      'metric' => '24',
    ),
    45 => 
    array (
      0 => '202308',
      'month' => '202308',
      1 => '12',
      'representation_id' => '12',
      2 => '17',
      'metric' => '17',
    ),
    46 => 
    array (
      0 => '202309',
      'month' => '202309',
      1 => '12',
      'representation_id' => '12',
      2 => '33',
      'metric' => '33',
    ),
    47 => 
    array (
      0 => '202310',
      'month' => '202310',
      1 => '12',
      'representation_id' => '12',
      2 => '57',
      'metric' => '57',
    ),
    48 => 
    array (
      0 => '202311',
      'month' => '202311',
      1 => '12',
      'representation_id' => '12',
      2 => '59',
      'metric' => '59',
    ),
    49 => 
    array (
      0 => '202312',
      'month' => '202312',
      1 => '12',
      'representation_id' => '12',
      2 => '41',
      'metric' => '41',
    ),
    50 => 
    array (
      0 => '202401',
      'month' => '202401',
      1 => '12',
      'representation_id' => '12',
      2 => '32',
      'metric' => '32',
    ),
    51 => 
    array (
      0 => '202402',
      'month' => '202402',
      1 => '12',
      'representation_id' => '12',
      2 => '65',
      'metric' => '65',
    ),
    52 => 
    array (
      0 => '202403',
      'month' => '202403',
      1 => '12',
      'representation_id' => '12',
      2 => '69',
      'metric' => '69',
    ),
    53 => 
    array (
      0 => '202404',
      'month' => '202404',
      1 => '12',
      'representation_id' => '12',
      2 => '54',
      'metric' => '54',
    ),
    54 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '12',
      'representation_id' => '12',
      2 => '52',
      'metric' => '52',
    ),
    55 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '12',
      'representation_id' => '12',
      2 => '40',
      'metric' => '40',
    ),
    56 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '12',
      'representation_id' => '12',
      2 => '22',
      'metric' => '22',
    ),
    57 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '12',
      'representation_id' => '12',
      2 => '21',
      'metric' => '21',
    ),
    58 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '12',
      'representation_id' => '12',
      2 => '64',
      'metric' => '64',
    ),
    59 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '12',
      'representation_id' => '12',
      2 => '96',
      'metric' => '96',
    ),
    60 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '12',
      'representation_id' => '12',
      2 => '92',
      'metric' => '92',
    ),
    61 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '12',
      'representation_id' => '12',
      2 => '42',
      'metric' => '42',
    ),
    62 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '12',
      'representation_id' => '12',
      2 => '22',
      'metric' => '22',
    ),
    63 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '12',
      'representation_id' => '12',
      2 => '26',
      'metric' => '26',
    ),
    64 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '12',
      'representation_id' => '12',
      2 => '25',
      'metric' => '25',
    ),
    65 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '12',
      'representation_id' => '12',
      2 => '14',
      'metric' => '14',
    ),
    66 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '12',
      'representation_id' => '12',
      2 => '24',
      'metric' => '24',
    ),
    67 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '12',
      'representation_id' => '12',
      2 => '24',
      'metric' => '24',
    ),
    68 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '12',
      'representation_id' => '12',
      2 => '10',
      'metric' => '10',
    ),
    69 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '12',
      'representation_id' => '12',
      2 => '7',
      'metric' => '7',
    ),
  ),
); ?>