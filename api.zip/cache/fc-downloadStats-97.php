<?php return array (
  97 => 
  array (
    0 => 
    array (
      0 => '202405',
      'month' => '202405',
      1 => '66',
      'representation_id' => '66',
      2 => '7',
      'metric' => '7',
    ),
    1 => 
    array (
      0 => '202406',
      'month' => '202406',
      1 => '66',
      'representation_id' => '66',
      2 => '24',
      'metric' => '24',
    ),
    2 => 
    array (
      0 => '202407',
      'month' => '202407',
      1 => '66',
      'representation_id' => '66',
      2 => '29',
      'metric' => '29',
    ),
    3 => 
    array (
      0 => '202408',
      'month' => '202408',
      1 => '66',
      'representation_id' => '66',
      2 => '7',
      'metric' => '7',
    ),
    4 => 
    array (
      0 => '202409',
      'month' => '202409',
      1 => '66',
      'representation_id' => '66',
      2 => '17',
      'metric' => '17',
    ),
    5 => 
    array (
      0 => '202410',
      'month' => '202410',
      1 => '66',
      'representation_id' => '66',
      2 => '23',
      'metric' => '23',
    ),
    6 => 
    array (
      0 => '202411',
      'month' => '202411',
      1 => '66',
      'representation_id' => '66',
      2 => '25',
      'metric' => '25',
    ),
    7 => 
    array (
      0 => '202412',
      'month' => '202412',
      1 => '66',
      'representation_id' => '66',
      2 => '42',
      'metric' => '42',
    ),
    8 => 
    array (
      0 => '202501',
      'month' => '202501',
      1 => '66',
      'representation_id' => '66',
      2 => '22',
      'metric' => '22',
    ),
    9 => 
    array (
      0 => '202502',
      'month' => '202502',
      1 => '66',
      'representation_id' => '66',
      2 => '18',
      'metric' => '18',
    ),
    10 => 
    array (
      0 => '202503',
      'month' => '202503',
      1 => '66',
      'representation_id' => '66',
      2 => '23',
      'metric' => '23',
    ),
    11 => 
    array (
      0 => '202504',
      'month' => '202504',
      1 => '66',
      'representation_id' => '66',
      2 => '22',
      'metric' => '22',
    ),
    12 => 
    array (
      0 => '202505',
      'month' => '202505',
      1 => '66',
      'representation_id' => '66',
      2 => '24',
      'metric' => '24',
    ),
    13 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '66',
      'representation_id' => '66',
      2 => '13',
      'metric' => '13',
    ),
    14 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '66',
      'representation_id' => '66',
      2 => '16',
      'metric' => '16',
    ),
    15 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '66',
      'representation_id' => '66',
      2 => '12',
      'metric' => '12',
    ),
    16 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '66',
      'representation_id' => '66',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>