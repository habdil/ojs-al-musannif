<?php return array (
  91 => 
  array (
    0 => 
    array (
      0 => '202506',
      'month' => '202506',
      1 => '84',
      'representation_id' => '84',
      2 => '6',
      'metric' => '6',
    ),
    1 => 
    array (
      0 => '202507',
      'month' => '202507',
      1 => '84',
      'representation_id' => '84',
      2 => '7',
      'metric' => '7',
    ),
    2 => 
    array (
      0 => '202508',
      'month' => '202508',
      1 => '84',
      'representation_id' => '84',
      2 => '6',
      'metric' => '6',
    ),
    3 => 
    array (
      0 => '202509',
      'month' => '202509',
      1 => '84',
      'representation_id' => '84',
      2 => '1',
      'metric' => '1',
    ),
  ),
); ?>