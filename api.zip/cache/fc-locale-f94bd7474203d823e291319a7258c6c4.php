<?php return array (
  'plugins.generic.driver.displayName' => 'DRIVER',
  'plugins.generic.driver.description' => 'The DRIVER plugin extends the OAI-PMH interface according to the DRIVER Guidelines 2.0, helping OJS journals to become DRIVER compliant.',
); ?>