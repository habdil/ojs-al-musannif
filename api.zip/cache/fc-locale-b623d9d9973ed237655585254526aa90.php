<?php return array (
  'plugins.reports.views.displayName' => 'View Report',
  'plugins.reports.views.description' => 'This plugin implements a CSV report describing readership for each article.',
  'plugins.reports.views.articleId' => 'Article ID',
  'plugins.reports.views.articleTitle' => 'Article Title',
  'plugins.reports.views.datePublished' => 'Date Published',
  'plugins.reports.views.abstractViews' => 'Abstract Views',
  'plugins.reports.views.galleyViews' => 'Total Galley Views',
); ?>