<?php return array (
  'baseColour' => '#4c8b35',
  'enabled' => true,
  'typography' => 'notoSans',
); ?>